/**
 * Created by Fay on 2017/9/11.
 *
 * Copyright (c) 2017 QuQ
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

/*----------------------------------
 网络请求
 ----------------------------------*/

var network = (function() {

    /* Private Member Variables */

    var n = {};


    /* Private Methods */

    /**
     * 发送网络请求
     *
     * @param method 请求方法
     * @param api 请求接口
     * @param params 请求参数
     * @param successCallback 请求成功回调
     * @param errorCallback 请求失败回调
     */
    function sendWithMethod(method, api, params, successCallback, errorCallback) {
        switch (method) {
            case 'GET':
                if (n.settings.framework === n.framework.AJAX) {
                    GET(n.settings.hostAddress + api, params, n.settings.timeout, n.settings.retryTimes, n.settings.dataType, successCallback, errorCallback);
                } else {
                    cordova.exec(null, null, 'Network', 'network_debug_mode', [n.debug]);
                    cordova.exec(successCallback, errorCallback, 'Network', 'network_request_get', [n.settings.hostAddress + api, params, n.settings.timeout, n.settings.retryTimes]);
                }
                break;
            case 'POST':
                if (n.settings.framework === n.framework.AJAX) {
                    POST(n.settings.hostAddress + api, params, n.settings.timeout, n.settings.retryTimes, n.settings.dataType, successCallback, errorCallback);
                } else {
                    cordova.exec(null, null, 'Network', 'network_debug_mode', [n.debug]);
                    cordova.exec(successCallback, errorCallback, 'Network', 'network_request_post', [n.settings.hostAddress + api, params, n.settings.timeout, n.settings.retryTimes]);
                }
                break;
            case 'DELETE':
                if (n.settings.framework === n.framework.AJAX) {
                    DELETE(n.settings.hostAddress + api, params, n.settings.timeout, n.settings.retryTimes, n.settings.dataType, successCallback, errorCallback);
                } else {
                    cordova.exec(null, null, 'Network', 'network_debug_mode', [n.debug]);
                    cordova.exec(successCallback, errorCallback, 'Network', 'network_request_delete', [n.settings.hostAddress + api, params, n.settings.timeout, n.settings.retryTimes]);
                }
                break;
        }
    }

    /**
     * 使用AJAX发送请求
     *
     * @param method 请求方法
     * @param url 请求地址
     * @param params 请求参数
     * @param timeout 超时间隔
     * @param retryTimes 请求失败重试次数，默认不重试
     * @param dataType 服务器返回数据的类型，网络框架为AJAX时使用，默认为text类型
     * @param successCallback 请求成功回调
     * @param errorCallback 请求失败回调
     */
    function sendByAJAX(method, url, params, timeout, retryTimes, dataType, successCallback, errorCallback) {

        if (debug) {// 调试信息
            console.log('[ QuQ ][ NETWORK ] Request sending with arguments.');
            console.log('[ QuQ ][ FRAMEWORK ] AJAX');
            console.log('[ QuQ ][ METHOD ] ' + method);
            console.log('[ QuQ ][ URL ] ' + url);
            console.log('[ QuQ ][ PARAMS ] ' + JSON.stringify(params));
            console.log('[ QuQ ][ RETRY ] ' + timeout);
            console.log('[ QuQ ][ TIMEOUT ] ' + retryTimes);
        }

        retryTimes--;
        $.ajax({
            data: params,
            dataType: dataType,
            method: method,
            timeout: timeout,
            url: url,

            // xhr: XMLHTTPRequest
            // 回调成功
            success: function (xhr, status, result) {

                // 请求结果状态码
                n.response.statusCode = result.status;

                // 解析请求结果
                var jsonResult = null;
                try {
                    jsonResult = JSON.parse(xhr);
                } catch (e) {

                }

                // 回调
                if (jsonResult !== null) {
                    if (n.debug) {// 调试信息
                        console.log('[ QuQ ][ NETWORK ] Request success.');
                    }
                    // 回调请求成功
                    n.response.result = jsonResult;
                    successCallback({'statusCode': result.status, 'result': jsonResult});
                } else {
                    if (n.debug) {// 调试信息
                        console.log('[ QuQ ][ NETWORK ] Request failure.');
                    }
                    // 回调请求失败
                    errorCallback({'statusCode': result.status, 'result': xhr});
                }
            },

            // 回调失败
            error: function (xhr, status, error) {
                if (retryTimes < 1) {
                    if (n.debug) {// 调试信息
                        console.log('[ QuQ ][ NETWORK ] Request failure.');
                    }
                    n.response.statusCode = error.status;
                    // 回调请求失败
                    errorCallback({'statusCode': error.status, 'result': xhr});
                    return;
                }
                sendByAJAX(url, params, timeout, retryTimes, dataType, successCallback, errorCallback);
            }
        });
    }

    /**
     * 发送GET请求
     *
     * @param url 请求地址
     * @param params 请求参数
     * @param timeout 超时间隔
     * @param retryTimes 请求失败重试次数，默认不重试
     * @param dataType 服务器返回数据的类型，网络框架为AJAX时使用，默认为text类型
     * @param successCallback 请求成功回调
     * @param errorCallback 请求失败回调
     * @constructor GET
     */
    function GET(url, params, timeout, retryTimes, dataType, successCallback, errorCallback) {
        sendByAJAX('GET', url, params, timeout, retryTimes, dataType, successCallback, errorCallback);
    }

    /**
     * 发送POST请求
     *
     * @param url 请求地址
     * @param params 请求参数
     * @param timeout 超时间隔
     * @param retryTimes 请求失败重试次数，默认不重试
     * @param dataType 服务器返回数据的类型，网络框架为AJAX时使用，默认为text类型
     * @param successCallback 请求成功回调
     * @param errorCallback 请求失败回调
     * @constructor POST
     */
    function POST(url, params, timeout, retryTimes, dataType, successCallback, errorCallback) {
        sendByAJAX('POST', url, params, timeout, retryTimes, dataType, successCallback, errorCallback);
    }

    /**
     * 发送DELETE请求
     *
     * @param url 请求地址
     * @param params 请求参数
     * @param timeout 超时间隔
     * @param retryTimes 请求失败重试次数，默认不重试
     * @param dataType 服务器返回数据的类型，网络框架为AJAX时使用，默认为text类型
     * @param successCallback 请求成功回调
     * @param errorCallback 请求失败回调
     * @constructor DELETE
     */
    function DELETE(url, params, timeout, retryTimes, dataType, successCallback, errorCallback) {
        sendByAJAX('DELETE', url, params, timeout, retryTimes, dataType, successCallback, errorCallback);
    }


    /* Public Member Variables */

    /**
     * 调试模式
     *
     * @type {boolean}
     */
    n.debug = false;

    /**
     * 网络请求框架
     *
     * @property AJAX JQuery -> AJAX
     * @property SYSTEM Android -> Volley / iOS -> AFNetworking
     *
     * @type {{AJAX: number, SYSTEM: number}}
     */
    n.framework = {
        AJAX: 0,
        SYSTEM: 1
    };

    /**
     * 网络请求默认设置
     *
     * @property dataType 服务器返回数据的类型，网络框架为AJAX时使用，默认为text类型
     * @property framework 网络请求使用的框架，默认使用系统请求
     * @property hostAddress 请求的主机地址
     * @property retryTimes 请求失败重试次数，默认不重试
     * @property retryInterval 重试间隔
     * @property timeout 超时间隔，单位为毫秒
     *
     * @type {{dataType: string, framework: number, hostAddress: string, retryTimes: number, timeout: number}}
     */
    n.settings = {
        api: '',
        dataType: 'text',
        framework: n.framework.SYSTEM,
        hostAddress: '',
        method: 'GET',
        params: null,
        retryTimes: 1,
        retryInterval: 0,
        timeout: 60000
    };


    /* Public Methods */

    /**
     * 发送网络请求
     *
     * @property GET HTTP/1.1 GET方法
     * @property POST HTTP/1.1 POST方法
     * @property DELETE HTTP/1.1 DELETE方法
     *
     * @param api 接口地址
     * @param params 请求参数
     * @param successCallback 请求成功回调
     * @param errorCallback 请求失败回调
     *
     * @type {{GET: network.request.GET, POST: network.request.POST, DELETE: network.request.DELETE, send: network.request.send}}
     */
    n.request = {
        GET: function (api, params, successCallback, errorCallback) {
            sendWithMethod('GET', api, params, successCallback, errorCallback);
        },
        POST: function (api, params, successCallback, errorCallback) {
            sendWithMethod('POST', api, params, successCallback, errorCallback);
        },
        DELETE: function (api, params, successCallback, errorCallback) {
            sendWithMethod('DELETE', api, params, successCallback, errorCallback);
        },
        send: function (successCallback, errorCallback) {
            sendWithMethod(n.settings.method, n.settings.api, n.settings.params, successCallback, errorCallback);
        }
    };

    /**
     * 网络请求响应
     *
     * @type {{statusCode: number, result: {}}}
     */
    n.response = {
        statusCode: 200,
        result: {}
    };

    return n;
})();
