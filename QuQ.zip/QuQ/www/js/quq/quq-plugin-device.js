/**
 * Created by fay on 2017/9/11.
 */

/*----------------------------------
 设备信息
 ----------------------------------*/

var device = (function() {

    /* Private Member Variables */

    var d = {};


    /* Public Member Variables */

    /**
     * 判断设备系统
     *
     * @property Android
     * @property iOS
     *
     * @type {{Android: device.info.Android, iOS: device.info.iOS}}
     */
    d.system = {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        }
    };


    /* Public Methods */



    return d;
})();
