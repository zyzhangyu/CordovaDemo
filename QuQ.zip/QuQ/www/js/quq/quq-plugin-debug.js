/*----------------------------------
     	应用调试
 ----------------------------------*/

var debug = (function() {

	/* Private Member Variables */

 	var d = {};


	/* Public Methods */

    /**
	 * 调试模式
	 *
     * @param openOrNot
     */
 	d.open = function(openOrNot) {
		network.debug = openOrNot;
    };

 	return d;
})();
