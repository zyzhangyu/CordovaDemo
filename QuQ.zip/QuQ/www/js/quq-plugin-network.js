/*----------------------------------
     	网络请求
 ----------------------------------*/

var Network = (function() {
	var network = {};

    // 主机地址
	network.hostAddress = '';

    // 网络请求参数设置
    network.requestSettings = {

    	// 超时时间
    	timeout: 30000,

    	// 接收的数据类型
    	dataType: 'text',

    	// 请求发送前
    	beforeSend: function() {
    		if (Debug.debugMode) {
    			console.log('[ QuQ ][ NETWORK ] Request started.');
    		}
    	},

    	// 请求成功
    	success: function(xhr, status, result) {
            if (Debug.debugMode) {
                console.log('[ QuQ ][ NETWORK ] Request success.');
                console.log('[ QuQ ][ NETWORK ][ RESULT ] ' + xhr);
                console.log('[ QuQ ][ NETWORK ][ STATUS ] ' + status);
                console.log('[ QuQ ][ NETWORK ][ INFO ] ' + result);
            }
        },

    	// 请求失败
    	error: function(xhr, status, error) {
            if (Debug.debugMode) {
                console.log('[ QuQ ][ NETWORK ] Request failure.');
                console.log('[ QuQ ][ NETWORK ][ RESULT ] ' + xhr);
                console.log('[ QuQ ][ NETWORK ][ STATUS ] ' + status);
                console.log('[ QuQ ][ NETWORK ][ INFO ] ' + error);
            }
        },

    	// 请求完成
    	complete: function() {
            if (Debug.debugMode) {
                console.log('[ QuQ ][ NETWORK ] Request finished.');
            }
    	}
    };

    // 配置网络请求
    network.requestOpen = function() {
    	// 相当于 $.ajax(); 的父方法，用于设置全局的请求参数。
    	$.ajaxSetup(network.requestSettings);

        if (Debug.debugMode) {
            console.log('[ QuQ ][ NETWORK ] Request opened.');
        }
    };

    // 发送GET请求
    network.get = function(api, success, failure) {
        if (Debug.debugMode) {
            console.log('[ QuQ ][ NETWORK ][ URL ] ' + network.host + api);
        }
        
    	$.ajax({
            url: network.host + api,
            success: function(xhr, status, result) {
                // 父类实现的方法
                // 拼接 $.ajaxSetup(); 方法中的 `success` 字段，用于继承它的方法。
                network.requestSettings.success.apply(this, arguments);

                // 子类自己实现的方法
                success(xhr);           
            },
            error: function(xhr, status, error) {
                // 父类实现的方法
                // 拼接 $.ajaxSetup(); 方法中的 `success` 字段，用于继承它的方法。
                network.requestSettings.error.apply(this, arguments);

                // 子类自己实现的方法
                failure(xhr);
            }
        });
    };

    return network;
})();
