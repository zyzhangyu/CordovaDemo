var adapter = (function() {

    /* Private Member Variables */

    var a = {};

    /**
     * 打印工程信息
     */
    a.log = function() {
        console.log("QuQ");
    };


    /* Public Methods */

    /**
     * 关闭web
     *
     * @param info
     */
    a.dismissWeb = function(info) {
        cordova.exec(function() {}, function() {}, 'Adapter', 'adapter_dismiss_web', [info]);
    };
    
    return a;
})();
