/*----------------------------------
     	应用调试
 ----------------------------------*/

var Debug = (function() {
 	var debug = {};

 	// 调试模式
 	debug.debugMode = false;

 	return debug;
})();
