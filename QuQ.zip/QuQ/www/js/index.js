var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    onDeviceReady: function() {
        var string = '';
        if (isMobile.Android()) {
            string = 'Hello, Android!';
        } else if (isMobile.iOS()) {
            string = 'Hello, iOS!';
        }

        // 按钮一
        var btn = document.getElementById('btn1');
        btn.onclick = function() {
            cordova.exec(function() {}, function() {}, 'Adapter', 'adapter_dismiss_web', [string]);
            Adapter.log();
        };

        // 打开调试模式
        Debug.debugMode = true;

        // 请求的主机地址
        Network.host = 'http://www.weather.com.cn/data/sk/';

        // 打开网络请求
        Network.requestOpen();
        
        // 按钮二
        var btn = document.getElementById('btn2');
        btn.onclick = function() {
            Network.requestOpen();
            // 发送GET请求
            Network.get('101010100.html', function(result) {
                console.log(result);
            }, function(error) {
                console.log(error);
            });
        };
    }
};

var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    }
};

function adapter_dismiss() {
    if (isMobile.Android()) {
        console.log('QuQ: Web dismiss!');
    } else if (isMobile.iOS()) {
        console.log('Web dismiss!');
    }
}


app.initialize();
