var app = {
    // 当接收到`deviceready`的信号后，web初始化完毕
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    onDeviceReady: function() {
        var string = '';
        if (device.system.Android()) {
            string = 'Bye, Android!';
        } else if (device.system.iOS()) {
            string = 'Bye, iOS!';
        }

        // 按钮一
        var btn1 = document.getElementById('btn1');
        btn1.onclick = function() {
            adapter.dismissWeb(string);
            adapter.log();
        };

        // 打开调试模式
        debug.open(true);

        // 请求的主机地址
        network.settings.hostAddress = 'http://www.weather.com.cn/data/sk/';

        // 按钮二
        var btn2 = document.getElementById('btn2');
        btn2.onclick = function() {
            network.settings.retryTimes = 3;
            network.request.GET('101010100.html', null, function(result) {
                console.log('QuQ -> ' + JSON.stringify(result));
            }, function(error) {
                console.log('QuQ -> ' + JSON.stringify(error));
            });
        };
    }
};

//关闭接口
function adapter_dismiss() {
    if (device.system.Android()) {
        console.log('QuQ: Web dismiss!');
    } else if (device.system.iOS()) {
        console.log('Web dismiss!');
    }
}


//初始化，打开web后跑的第一个方法
app.initialize();
