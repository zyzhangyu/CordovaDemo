var Adapter = (function() {
    var adapter = {};
               
    adapter.log = function() {
        console.log("QuQ");
    };
               
    return adapter;
})();
