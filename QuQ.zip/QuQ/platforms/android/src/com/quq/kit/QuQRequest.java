package com.quq.kit;

import android.app.Activity;
import android.util.Log;

import com.android.volley.NetworkResponse;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

/**
 * Created by fay on 2017/9/6.
 */

public class QuQRequest {
    public int statusCode;

    public QuQRequest(Activity activity) {
        
        // 创建请求队列
        RequestQueue queue = Volley.newRequestQueue(activity);

        // 普通方法
//        JsonObjectRequest request = new JsonObjectRequest("", null, new Response.Listener<JSONObject>() {
//            @Override
//            public void onResponse(JSONObject response) {
//                Log.i("QuQ", response.toString());
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Log.i("QuQ", error.toString());
//            }
//        }) {// 重写父类方法，获取请求完成时的状态码
//            @Override
//            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
//                if (response != null) {
//                    statusCode = response.statusCode;
//                }
//                return super.parseNetworkResponse(response);
//            }
//        };

        // 闭包方法
        JsonObjectRequest request = new JsonObjectRequest("http://www.weather.com.cn/data/sk/101010100.html", null, response -> {
            Log.i("QuQ", String.valueOf(statusCode));
        }, error -> {
            Log.i("QuQ", error.toString());
        }) {// 重写父类方法，获取请求完成时的状态码
            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                if (response != null) {
                    statusCode = response.statusCode;
                }
                return super.parseNetworkResponse(response);
            }
        };

        // 添加请求到队列
        queue.add(request);
    }
}
