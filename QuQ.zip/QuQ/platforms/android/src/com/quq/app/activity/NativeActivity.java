package com.quq.app.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.quq.app.R;

import org.json.JSONObject;

/**
 * Created by fay on 2017/8/4.
 */

public class NativeActivity extends Activity {

    // 请求结果状态码
    private int statusCode;

    //region Views Life Cycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native);
    }

    //endregion


    //region Events Management

    public void closeMe(View v) {
        finish();
    }

    public void requestNetwork(View v) {

        // 创建请求队列（异步请求）
        RequestQueue queue = Volley.newRequestQueue(this);

        // 创建网络请求（发送GET请求）
        JsonObjectRequest request = new JsonObjectRequest("http://www.weather.com.cn/data/sk/101010100.html", null, response -> {

            // 请求结果状态码
            Log.i("QuQ", String.valueOf(statusCode));

            Log.i("QuQ", response.toString());
        }, error -> {

            // 请求结果状态码
            Log.i("QuQ", String.valueOf(error.networkResponse.statusCode));

            Log.i("QuQ", error.toString());
        }) {// 重写网络响应的方法
            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                statusCode = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };

        // 添加请求超时间隔（30000毫秒-30秒），重试次数1次（失败不再重试），规避次数1f
        request.setRetryPolicy(new DefaultRetryPolicy(30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // 添加请求到队列
        queue.add(request);
    }

    //endregion
}
