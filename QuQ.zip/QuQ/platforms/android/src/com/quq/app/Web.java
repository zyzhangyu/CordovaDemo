package com.quq.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import org.apache.cordova.CordovaActivity;

/**
 * Created by fay on 2017/9/8.
 */

public class Web extends CordovaActivity {

    //region View Life Cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // enable Cordova apps to be started in the background
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getBoolean("cdvStartInBackground", false)) {
            moveTaskToBack(true);
        }

        // Set by <content src="index.html" /> in config.xml
        loadUrl(launchUrl);
    }

    //endregion


    //region Public Methods

    public static void start(Activity activity) {
        Intent intent = new Intent(activity, Web.class);
        activity.startActivity(intent);
    }

    //endregion
}
