//
//  QuQNetwork.m
//  QuQ
//
//  Created by Fay on 2017/9/9.
//
//  Copyright (c) 2017 QuQ
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

#import "QuQNetwork.h"
#import <AFNetworking/AFNetworking.h>

@interface QuQNetwork ()

//调试模式
@property (nonatomic, assign) BOOL debug;

//创建请求
@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end

@implementation QuQNetwork

#pragma mark - Setter / Getter Methods

//初始化请求
- (AFHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [AFHTTPSessionManager manager];
        _manager.responseSerializer.acceptableContentTypes = [_manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    }
    return _manager;
}


#pragma mark - Private Methods

//发送GET请求
- (void)GET:(NSString *)url params:(NSDictionary *)params retryTimes:(NSInteger)retryTimes command:(CDVInvokedUrlCommand *)command
{
    if (self.debug) {// 调试信息
        NSLog(@"[ QuQ ][ NETWORK ] Request sending with arguments.");
        NSLog(@"[ QuQ ][ FRAMEWORK ] SYSTEM");
        NSLog(@"[ QuQ ][ METHOD ] GET");
        NSLog(@"[ QuQ ][ URL ] %@", url);
        NSLog(@"[ QuQ ][ PARAMS ] %@", params);
        NSLog(@"[ QuQ ][ RETRY] %@", @(retryTimes));
        NSLog(@"[ QuQ ][ TIMEOUT ] %@", @(self.manager.requestSerializer.timeoutInterval));
    }
    
    retryTimes--;
    [self.manager GET:url parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
        [self callback:task result:responseObject command:command];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        if (retryTimes < 1) {
            [self callback:task result:[NSString stringWithFormat:@"%@", error] command:command];
            return;
        }
        [self GET:url params:params retryTimes:retryTimes command:command];
    }];
}

//发送POST请求
- (void)POST:(NSString *)url params:(NSDictionary *)params retryTimes:(NSInteger)retryTimes command:(CDVInvokedUrlCommand *)command
{
    if (self.debug) {// 调试信息
        NSLog(@"[ QuQ ][ NETWORK ] Request sending with arguments.");
        NSLog(@"[ QuQ ][ FRAMEWORK ] SYSTEM");
        NSLog(@"[ QuQ ][ METHOD ] POST");
        NSLog(@"[ QuQ ][ URL ] %@", url);
        NSLog(@"[ QuQ ][ PARAMS ] %@", params);
        NSLog(@"[ QuQ ][ RETRY] %@", @(retryTimes));
        NSLog(@"[ QuQ ][ TIMEOUT ] %@", @(self.manager.requestSerializer.timeoutInterval));
    }
    
    retryTimes--;
    [self.manager POST:url parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
        [self callback:task result:responseObject command:command];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        if (retryTimes < 1) {
            [self callback:task result:[NSString stringWithFormat:@"%@", error] command:command];
            return;
        }
        [self POST:url params:params retryTimes:retryTimes command:command];
    }];
}

//发送POST请求带参数
- (void)POST:(NSString *)url params:(NSDictionary *)params body:(void (^)(id <AFMultipartFormData> formData))body retryTimes:(NSInteger)retryTimes command:(CDVInvokedUrlCommand *)command
{
    if (self.debug) {// 调试信息
        NSLog(@"[ QuQ ][ NETWORK ] Request sending with arguments.");
        NSLog(@"[ QuQ ][ FRAMEWORK ] SYSTEM");
        NSLog(@"[ QuQ ][ METHOD ] POST");
        NSLog(@"[ QuQ ][ URL ] %@", url);
        NSLog(@"[ QuQ ][ PARAMS ] %@", params);
        NSLog(@"[ QuQ ][ RETRY] %@", @(retryTimes));
        NSLog(@"[ QuQ ][ TIMEOUT ] %@", @(self.manager.requestSerializer.timeoutInterval));
    }
    
    retryTimes--;
    [self.manager POST:url parameters:params constructingBodyWithBlock:body success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [self callback:task result:responseObject command:command];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (retryTimes < 1) {
            [self callback:task result:[NSString stringWithFormat:@"%@", error] command:command];
            return;
        }
        [self POST:url params:params body:body retryTimes:retryTimes command:command];
    }];
}

//发送DELETE请求
- (void)DELETE:(NSString *)url params:(NSDictionary *)params retryTimes:(NSInteger)retryTimes command:(CDVInvokedUrlCommand *)command
{
    if (self.debug) {// 调试信息
        NSLog(@"[ QuQ ][ NETWORK ] Request sending with arguments.");
        NSLog(@"[ QuQ ][ FRAMEWORK ] SYSTEM");
        NSLog(@"[ QuQ ][ METHOD ] DELETE");
        NSLog(@"[ QuQ ][ URL ] %@", url);
        NSLog(@"[ QuQ ][ PARAMS ] %@", params);
        NSLog(@"[ QuQ ][ RETRY] %@", @(retryTimes));
        NSLog(@"[ QuQ ][ TIMEOUT ] %@", @(self.manager.requestSerializer.timeoutInterval));
    }
    
    retryTimes--;
    [self.manager DELETE:url parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        [self callback:task result:responseObject command:command];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (retryTimes < 1) {
            [self callback:task result:[NSString stringWithFormat:@"%@", error] command:command];
            return;
        }
        [self DELETE:url params:params retryTimes:retryTimes command:command];
    }];
}

//处理请求结果并回调到JavaScript
- (void)callback:(NSURLSessionTask *)task result:(id)result command:(CDVInvokedUrlCommand *)command
{
    // 请求结果状态码
    NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
    NSInteger statusCode = [response statusCode];
    
    if ([result isKindOfClass:[NSDictionary class]]) {
        if (self.debug) {// 调试信息
            NSLog(@"[ QuQ ][ NETWORK ] Request success.");
        }
        [self sendStatus:CDVCommandStatus_OK message:@{@"statusCode": @(statusCode), @"result": result} command:command];
    } else {
        if (self.debug) {// 调试信息
            NSLog(@"[ QuQ ][ NETWORK ] Request failure.");
        }
        [self sendStatus:CDVCommandStatus_ERROR message:@{@"statusCode": @(statusCode), @"result": result} command:command];
    }
}


#pragma mark - CDVPlugin Methods

//发送到JS的回调
- (void)sendStatus:(CDVCommandStatus)status message:(NSObject *)message command:(CDVInvokedUrlCommand *)command
{
    CDVPluginResult *pluginResult = nil;
    if ([message isKindOfClass:[NSString class]]) {
        pluginResult = [CDVPluginResult resultWithStatus:status messageAsString:(NSString *)message];
    } else if ([message isKindOfClass:[NSArray class]]) {
        pluginResult = [CDVPluginResult resultWithStatus:status messageAsArray:(NSArray *)message];
    } else if ([message isKindOfClass:[NSDictionary class]]) {
        pluginResult = [CDVPluginResult resultWithStatus:status messageAsDictionary:(NSDictionary *)message];
    } else {
        pluginResult = [CDVPluginResult resultWithStatus:status];
    }
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}


#pragma mark - Cordova Plugin Methods (JavaScript -> Objective-C)

//JS调用调试模式
- (void)network_debug_mode:(CDVInvokedUrlCommand *)command
{
    self.debug = command.arguments[0];
}

//JS调用发送GET请求
- (void)network_request_get:(CDVInvokedUrlCommand *)command
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        self.manager.requestSerializer.timeoutInterval = [command.arguments[2] integerValue]/1000;
        [self GET:command.arguments[0] params:command.arguments[1] retryTimes:[command.arguments[3] integerValue] command:command];
    });
}

//JS调用发送POST请求
- (void)network_request_post:(CDVInvokedUrlCommand *)command
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        self.manager.requestSerializer.timeoutInterval = [command.arguments[2] integerValue]/1000;
        [self POST:command.arguments[0] params:command.arguments[1] retryTimes:[command.arguments[3] integerValue] command:command];
    });
}

//JS调用发送POST请求带参数
- (void)network_request_post_file:(CDVInvokedUrlCommand *)command
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        self.manager.requestSerializer.timeoutInterval = [command.arguments[2] integerValue]/1000;
        [self POST:command.arguments[0] params:command.arguments[1] body:^(id<AFMultipartFormData> formData) {
            
        } retryTimes:[command.arguments[3] integerValue] command:command];
    });
}

//JS调用发送DELETE请求
- (void)network_request_delete:(CDVInvokedUrlCommand *)command
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        self.manager.requestSerializer.timeoutInterval = [command.arguments[2] integerValue]/1000;
        [self DELETE:command.arguments[0] params:command.arguments[1] retryTimes:[command.arguments[3] integerValue] command:command];
    });
}

@end
