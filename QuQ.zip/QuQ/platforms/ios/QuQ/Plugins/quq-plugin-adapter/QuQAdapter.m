//
//  QuQAdapter.m
//  QuQ
//
//  Created by Fay on 2017/8/4.
//
//

#import "QuQAdapter.h"
#import "QuQView.h"

@implementation QuQAdapter

#pragma mark - Cordova Plugin Methods (JavaScript -> Objective-C)

//关闭页面
- (void)adapter_dismiss_web:(CDVInvokedUrlCommand *)command
{
    NSLog(@"%@", command.arguments[0]);
    [self.viewController dismissViewControllerAnimated:YES completion:NULL];
    [self adapterDismiss];
}

//显示提示框
- (void)adapter_show_alert:(CDVInvokedUrlCommand *)command
{
    __weak __typeof__(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __typeof__(weakSelf) self = weakSelf;
        [self.viewController presentViewController:[QuQAlert alertWithMessages:command.arguments[0], command.arguments[1],
                                                    command.arguments[2], ^{
                                                        [self sendStatus:CDVCommandStatus_OK message:nil command:command];
                                                    },
                                                    command.arguments[3], ^{
                                                        [self sendStatus:CDVCommandStatus_ERROR message:nil command:command];
                                                    }, nil] animated:YES completion:NULL];
    });
}


#pragma mark - Cordova Plugin Methods (Objective-C -> JavaScript)

- (void)adapterDismiss
{
    [self.commandDelegate evalJs:@"adapter_dismiss()"];
}


#pragma mark - CDVPlugin Methods

//发送到JS的回调
- (void)sendStatus:(CDVCommandStatus)status message:(NSObject *)message command:(CDVInvokedUrlCommand *)command
{
    CDVPluginResult *pluginResult = nil;
    if ([message isKindOfClass:[NSString class]]) {
        pluginResult = [CDVPluginResult resultWithStatus:status messageAsString:(NSString *)message];
    } else if ([message isKindOfClass:[NSArray class]]) {
        pluginResult = [CDVPluginResult resultWithStatus:status messageAsArray:(NSArray *)message];
    } else if ([message isKindOfClass:[NSDictionary class]]) {
        pluginResult = [CDVPluginResult resultWithStatus:status messageAsDictionary:(NSDictionary *)message];
    } else {
        pluginResult = [CDVPluginResult resultWithStatus:status];
    }
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

@end
