//
//  QuQAdapter.h
//  QuQ
//
//  Created by Fay on 2017/8/4.
//
//

#import <Cordova/CDV.h>

@interface QuQAdapter : CDVPlugin

@end
