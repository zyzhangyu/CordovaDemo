//
//  QuQNativeViewController.m
//  QuQ
//
//  Created by Fay on 2017/8/4.
//
//

#import "QuQNativeViewController.h"
#import <AFNetworking/AFNetworking.h>

@interface QuQNativeViewController ()

@end

@implementation QuQNativeViewController

#pragma mark - Views Life Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


#pragma mark - Events Management

- (IBAction)closeMe:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)requestNetwork:(id)sender
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manager GET:@"http://www.weather.com.cn/data/sk/101010100.html" parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        NSLog(@"%@", responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@", error);
    }];
}


#pragma mark - Memory Managements

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
