//
//  QuQWeb.m
//  QuQ
//
//  Created by Fay on 2017/9/8.
//
//

#import "QuQWeb.h"

@interface QuQWeb ()

@end

@implementation QuQWeb

#pragma mark - View Life Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


#pragma mark - Public Methods

//打开WebApp
+ (void)showAboveViewController:(UIViewController *)viewController
{
    QuQWeb *web = [[QuQWeb alloc] init];
    [viewController presentViewController:web animated:YES completion:NULL];
}


#pragma mark - Memory Management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

@implementation QuQCommandDelegate

@end

@implementation QuQCommandQueue

@end
