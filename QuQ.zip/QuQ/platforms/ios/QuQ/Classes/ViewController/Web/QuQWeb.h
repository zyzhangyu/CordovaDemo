//
//  QuQWeb.h
//  QuQ
//
//  Created by Fay on 2017/9/8.
//
//

#import <Cordova/CDV.h>
#import <Cordova/CDVCommandDelegateImpl.h>
#import <Cordova/CDVCommandQueue.h>

@interface QuQWeb : CDVViewController

/**
 打开WebApp
 
 @param viewController 当前处于显示状态的视图控制器
 */
+ (void)showAboveViewController:(UIViewController *)viewController;

@end

@interface QuQCommandDelegate : CDVCommandDelegateImpl

@end

@interface QuQCommandQueue : CDVCommandQueue

@end
