//
//  QuQNativeViewController.h
//  QuQ
//
//  Created by Fay on 2017/8/4.
//
//

#import <UIKit/UIKit.h>

@interface QuQNativeViewController : UIViewController

@property (nonatomic, copy) NSString *value;


@end
